## Description
Plays the Thomas the Tank Engine theme whenever a thumper starts chasing you.

## WIP
Working on transmitting the Thomas theme through walkie-talkies.

## Changelog
#### Version 1.0.1
The mod actually should work now, my bad :P