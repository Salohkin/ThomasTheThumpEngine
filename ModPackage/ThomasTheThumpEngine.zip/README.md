## Description
Plays the Thomas the Tank Engine theme whenever a thumper starts chasing you.

## TODO
* Transmit the Thomas theme through walkie-talkies.