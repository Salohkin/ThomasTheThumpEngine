#### Version 1.0.3
* Theme stops when thumper loses the player
#### Version 1.0.2
* Now plays for all players, instead of just the host
#### Version 1.0.1
* The mod actually should work now, my bad :P

