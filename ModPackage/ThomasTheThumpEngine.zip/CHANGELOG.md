#### Version 1.0.4
* Theme stops when thumper dies
#### Version 1.0.3
* Theme stops when thumper loses the player
#### Version 1.0.2
* Now plays for all players, instead of just the host
#### Version 1.0.1
* The mod actually should work now (edit: this version only works for the host)

