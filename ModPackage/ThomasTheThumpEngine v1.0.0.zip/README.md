A Lethal Company mod that plays the Thomas the Tank Engine theme when a thumper is chasing a player.
